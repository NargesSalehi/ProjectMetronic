export { KTTooltip } from './tooltip';
export { KTTooltipConfigInterface, KTTooltipInterface } from './types';