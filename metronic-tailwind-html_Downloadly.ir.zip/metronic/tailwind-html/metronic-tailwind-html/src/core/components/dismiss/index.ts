export { KTDismiss } from './dismiss';
export { KTDismissConfigInterface, KTDismissInterface } from './types';
