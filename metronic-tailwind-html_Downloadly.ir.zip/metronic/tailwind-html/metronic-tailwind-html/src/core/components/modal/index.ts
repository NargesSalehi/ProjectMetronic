export { KTModal } from './modal';
export { KTModalConfigInterface, KTModalInterface } from './types';
