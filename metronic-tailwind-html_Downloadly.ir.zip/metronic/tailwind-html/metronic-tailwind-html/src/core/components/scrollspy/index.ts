export { KTScrollspy } from './scrollspy';
export { KTScrollspyConfigInterface, KTScrollspyInterface } from './types';
