# Metronic 9 | Tailwind CSS based HTML & JavaScript Toolkit for Modern Web Applications

- Quick start guide [Online Documentation](https://keenthemes.com/metronic/tailwind/docs)

- For any theme related questions go to our [Support Center](https://devs.keenthemes.com)

- Save time on Metronic projects with our HTML file-based mini CMS tool [Metronic Composer](https://keenthemes.com/metronic/tailwind/docs/composer)

- Using Metronic 9 in a new project or for a new client ? Purchase a new license from [Themeforest](https://1.envato.market/EA4JP)
  or check out [License FAQ](https://keenthemes.com/metronic/tailwind/docs/getting-started/licensee) to find out more information about licenses.

- Stay tuned for updates via [Twitter](https://twitter.com/keenthemes) and check our marketplace for more amazing products [Keenthemes Marketplace](https://keenthemes.com)

"The only way to do great work is to love what you do"
-- Steve Jobs